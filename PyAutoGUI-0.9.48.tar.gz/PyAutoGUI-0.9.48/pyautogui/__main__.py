from . import displayMousePosition
displayMousePosition()